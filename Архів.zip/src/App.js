import './App.css';
import './heder/heder.css'
import './main/main.css'
import './footer/footer.css'
import logo from './imges/logo.png'
// import * as axios from "axios"
const App = () => {
    // const token = 'oamxKy8o4BHsXdjF9X59jA';

    // axios.get(`https://api.stackexchange.com/2.2/apps/${token}/de-authenticate`)
    //     .then(resp => resp.json())
    //     .then(data => { console.log(data) })
    return (< div className='box'>
        <div className="heder">
            <img src={logo} alt='logoStackOverflow' />
            <div className='textLogo'>
                <span>stack</span>
                <span className='boldText'>overflow uSof</span>
                <input className='search' type='text' placeholder='Search' />
            </div>
            <button className='logIn' type="button">Log in</button>
        </div>
        <div className="main">
            <div className='leftPanel'>123</div>
            <div className='rightPanel'>234</div>
        </div>
        <div className="footer"></div>
    </div>)
}
export default App


// User Authorized with account id = 20798816, got access token = oamxKy8o4BHsXdjF9X59jA))